<!DOCTYPE html>
<html lang="en">
    <head>
        <!--====== Required meta tags ======-->
    <meta charset="utf-8">
    <meta http-equiv="易付通 - 行业领先的免签约支付平台" content="ie=edge">
    <meta name="description" content="易付通是雾漫花网络工作室旗下的免签约支付产品，完美解决支付难题，一站式接入支付宝，微信，财付通，QQ钱包,微信wap，帮助开发者快速集成到自己相应产品，效率高，见效快，费率低！。">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>易付通 - 行业领先的免签约支付平台</title>
    <meta name="description" content="易付通是雾漫花网络工作室旗下的免签约支付产品，完美解决支付难题，一站式接入支付宝，微信，财付通，QQ钱包,微信wap，帮助开发者快速集成到自己相应产品，效率高，见效快，费率低！">
    <meta name="keywords" content="易付通,支付宝免签约即时到账,财付通免签约,微信免签约支付,QQ钱包免签约,免签约支付">
        <!--====== Title ======-->
        <title>Saap - Sass Landing HTML Template</title>
        <!--====== Favicon Icon ======-->
        <link rel="shortcut icon" href="https://www.wmhua.cn/i/2025/01/12/6783459906664.ico" type="image/png">
        <!--====== FontAwesome css ======-->
        <link rel="stylesheet" href="assets/fonts/fontawesome/css/all.min.css">
        <!--====== FontAwesome css ======-->
        <link rel="stylesheet" href="assets/fonts/flaticon/flaticon.css">
        <!--====== Bootstrap css ======-->
        <link rel="stylesheet" href="assets/vendor/bootstrap/css/bootstrap.min.css">
        <!--====== magnific-popup css ======-->
        <link rel="stylesheet" href="assets/vendor/magnific-popup/dist/magnific-popup.css">
        <!--====== Slick-popup css ======-->
        <link rel="stylesheet" href="assets/vendor/slick/slick.css">
        <!--====== Sal Animate css ======-->
        <link rel="stylesheet" href="assets/vendor/aos/aos.css">
        <!--====== Default css ======-->
        <link rel="stylesheet" href="assets/css/default.css">
        <!--====== Style css ======-->
        <link rel="stylesheet" href="assets/css/style.css">
        <!--====== Responsive css ======-->
        
    </head>
    <body>
        <!--====== Start Preloader ======-->
        <div class="preloader">
            <div class="loader">
                <div class="pre-shadow"></div>
                <div class="pre-box"></div>
            </div>
        </div>
        <!--====== End Preloader ======-->
        <!--====== Search From ======-->
		<div class="modal fade" id="search-modal">
            <div class="modal-dialog modal-dialog-centered" role="document">
                <div class="modal-content">
                    <form>
                        <div class="form_group">
                        	<input type="text" class="form_control" placeholder="Search here...">
                        	<button class="search_btn"><i class="fa fa-search"></i></button>
                        </div>
                    </form>
                </div>
            </div>
        </div><!--====== Search From ======-->
        <!--====== Start Header Section ======-->
        <header class="theme-header transparent-header">
            <div class="header-navigation navigation-white">
                <div class="nav-overlay"></div>
                <div class="container">
                    <div class="primary-menu">
                        <div class="site-branding">
                            <a href="index.html" class="brand-logo"><img src="https://www.wmhua.cn/i/2025/01/12/678342fdcf356.png" alt="Site Logo"></a>
                        </div>
                        <div class="nav-menu nav-ml-auto">
                            <!-- Navbar logo -->
                            <div class="sidebar-logo">
                                <a href="index.html" class="brand-logo"><img src="https://www.wmhua.cn/i/2025/01/12/678342fdcf356.png" alt="Site Logo"></a>
                            </div>
                            <!-- Navbar Close -->
                            <div class="navbar-close"><i class="far fa-times"></i></div>
                            <!-- Nav Menu -->
                            <nav class="main-menu">
                                <ul>
                                    <li class="mil-active">
                            <a href="./">网站首页</a>
                        </li>
                        <li>
                            <a href="user/test.php">在线测试</a>
                        </li>
                        <li>
                            <a href="/doc/index.html">开放文档</a>
                        </li>
                        <li>
                            <a href="/agreement.html">法律政策</a>
                        </li>
                        <li>
                            <a href="/user/reg.php">商户注册</a>
                        </li>
                                </ul>
                            </nav>
                        </div>
                        <div class="header-right-nav">
                            <ul class="d-inline-flex align-items-center">
                                <li class="nav-button"><a href="/user/login.php" class="main-btn bordered-btn">商户登录</a></li>
                                <li class="nav-toggle-btn">
                                    <div class="navbar-toggler">
                                        <span></span>
                                        <span></span>
                                        <span></span>
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </header>
        <!--====== End Header Section ======-->
        <!--====== Start Hero Section ======-->
        <section class="hero-area hero-style-one bg_cover" style="background-image:url(assets/images/hero/hero-bg-1.png)">
            <div class="hero-shape shape-one scene"><span data-depth="1"></span></div>
            <div class="hero-shape shape-two scene"><span data-depth="2"></span></div>
            <div class="hero-shape shape-three scene"><span data-depth=".5"></span></div>
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-8">
                        <div class="hero-content text-center">
                            <h1 data-aos="fade-up">全新支付体验</h1>
                            <a class="main-btn btn-white" data-aos="fade-up">极速响应、安全可靠、方便快捷是我们最大的特点，轻松实现手机付款、在线付款。</a>
                        </div>
                    </div>
                </div>
                <div class="hero-img animate-float-y">
                    <img src="assets/images/hero/hero-img-1.png" alt="Hero Image">
                </div>
            </div>
        </section><!--====== End Hero Section ======-->
        <!--====== Start Features Section ======-->
        <section class="features-area pb-30">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section-title text-center mb-55" data-aos="fade-up">
                            <span class="sub-title sub-title-bg">全新支付体验</span>
                            <h2>极速响应、安全可靠。</h2>
                        </div>
                    </div>
                </div>
                <div class="row justify-content-center">
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="block-style-one block-icon-animate animated-hover-icon mb-40" data-aos="fade-up" data-aos-delay="30">
                            <div class="icon">
                                <i class="flaticon-shuttle"></i>
                            </div>
                            <div class="text">
                                <h3 class="title">服务器安全</h3>
                                <p>采用群集服务器，防御高，故障率低，无论用户身在何方，均能获得流畅安全可靠的体验 </p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="block-style-one block-icon-animate animated-hover-icon mb-40" data-aos="fade-up" data-aos-delay="60">
                            <div class="icon">
                                <i class="flaticon-line-graph"></i>
                            </div>
                            <div class="text">
                                <h3 class="title">资金保障</h3>
                                <p>结算及时，资金秒到，资金平均停留的时间不超过12小时，您的资金安全将得到充分的保障。</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-4 col-md-6 col-sm-12">
                        <div class="block-style-one block-icon-animate animated-hover-icon mb-40" data-aos="fade-up" data-aos-delay="90">
                            <div class="icon">
                                <i class="flaticon-responsive"></i>
                            </div>
                            <div class="text">
                                <h3 class="title">持续更新</h3>
                                <p>系统持续更新，功能持续完善，让商户以及客户的体验不断接近完美是我们一直不变的追求。</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--====== End Features Section ======-->
        <!--====== Start Text Block Section ======-->
        <section class="fancy-text-block fancy-text-block-one pb-45">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-5">
                        <div class="text-wrapper mb-25" data-aos="fade-up">
                            <div class="section-title mb-20">
                                <span class="sub-title sub-title-bg">全新的支付系统</span>
                                <h2>专业的技术团队与资源</h2>
                            </div>
                            <p>专业的技术团队与行业资源意味着拥有一支由行业专家和专业技术人才组成的团队，具备丰富的实践经验和专业技能，能够为企业提供全方位、个性化的服务 。</p>
                            <a href="/user/login.php" class="main-btn bordered-btn bordered-blue">商户登录</a>
                        </div>
                    </div>
                    <div class="col-lg-7">
                        <div class="img-holder mb-25">
                            <div class="shape shape-one scene">
                                <span data-depth="3"><img src="assets/images/shape/object-1.png" alt="object"></span>
                            </div>
                            <img src="assets/images/block/img-1.jpg" class="img-one animate-float-y" alt="">
                            <img src="assets/images/block/img-2.jpg" class="img-two animate-float-x" alt="">
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--====== End Text Block Section ======-->
        <!--====== Start Text Block Section ======-->
        <section class="fancy-text-block fancy-text-block-two pb-55">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-lg-7">
                        <div class="img-holder mb-50">
                            <div class="shape shape-one scene">
                                <span data-depth="4"><img src="assets/images/shape/object-1.png" alt="object"></span>
                            </div>
                            <img src="assets/images/block/img-1.jpg" class="img-one animate-float-y" alt="">
                            <img src="assets/images/block/img-2.jpg" class="img-two animate-float-X" alt="">
                        </div>
                    </div>
                    <div class="col-lg-5">
                        <div class="text-wrapper mb-50" data-aos="fade-up">
                            <div class="section-title mb-20">
                                <span class="sub-title sub-title-bg">全新的支付系统</span>
                                <h2>一站式的平台管理系统</h2>
                            </div>
                            <p>无论是平台自营或是代理，均能进行层级管理，全局把控交易和财务，实现自由灵活的商户交易管理，并能与合作伙伴便捷分享利益。</p>
                            <ul class="check-list-one mb-40">
                                <li class="bg-one">长期稳定支付通道</li>
                                <li class="bg-two">方便快捷账号管理</li>
                                <li class="bg-two">高效实时监控订单</li>
                            </ul>
                            <a href="/user/login.php" class="main-btn bordered-btn bordered-blue">商户登录</a>
                        </div>
                    </div>
                </div>
            </div>
        </section><!--====== End Text Block Section ======-->
        <!--====== Start Counter Section ======-->
        <section class="counter-area counter-style-one blue-dark pt-100 pb-55">
            <div class="shape shape-one scene"><span data-depth="4"></span></div>
            <div class="shape shape-two scene"><span data-depth="3"></span></div>
            <div class="shape shape-three scene"><span data-depth=".5"></span></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="counter-item mb-40 animated-hover-icon text-center" data-aos="fade-up" data-aos-delay="30">
                            <div class="icon">
                                <i class="flaticon-project-management"></i>
                            </div>
                            <div class="text">
                                <h2 class="number"><span class="count">3556</span>+</h2>
                                <p>站点运行</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="counter-item mb-40 animated-hover-icon text-center" data-aos="fade-up" data-aos-delay="40">
                            <div class="icon">
                                <i class="flaticon-rating"></i>
                            </div>
                            <div class="text">
                                <h2 class="number"><span class="count">356</span>+</h2>
                                <p>站点结算</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="counter-item mb-40 text-center animated-hover-icon" data-aos="fade-up" data-aos-delay="50">
                            <div class="icon">
                                <i class="flaticon-medal"></i>
                            </div>
                            <div class="text">
                                <h2 class="number"><span class="count">3556</span>+</h2>
                                <p>站点订单</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6 col-sm-12">
                        <div class="counter-item mb-40 text-center animated-hover-icon" data-aos="fade-up" data-aos-delay="60">
                            <div class="icon">
                                <i class="flaticon-crown"></i>
                            </div>
                            <div class="text">
                                <h2 class="number"><span class="count">356</span>+</h2>
                                <p>站点会员</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--====== End Counter Section ======-->
        <!--====== Start Services Section ======-->
        <section class="services-area pt-130 pb-100">
            <div class="container">
                <div class="row justify-content-center">
                    <div class="col-lg-6">
                        <div class="section-title text-center mb-55" data-aos="fade-up">
                            <span class="sub-title sub-title-bg">全新的支付系统</span>
                            <h2>凭什么选择我们？</h2>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6 col-sm-12">
                        <div class="block-style-two block-icon-animate animated-hover-icon d-flex mb-30" data-aos="fade-up" data-aos-delay="30">
                            <div class="icon bg-one">
                                <i class="flaticon-analytics"></i>
                            </div>
                            <div class="text">
                                <p>提供稳定可靠的支付通道，保障每一笔交易的安全与顺畅。通过高效的支付系统设计，确保支付过程的稳定性，同时支持多种支付方式，满足不同用户的需求。提供流畅的支付体验。</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="block-style-two block-icon-animate animated-hover-icon d-flex mb-30" data-aos="fade-up" data-aos-delay="40">
                            <div class="icon bg-two">
                                <i class="flaticon-email"></i>
                            </div>
                            <div class="text">
                                <p>采用高效的账号管理系统，简化登录流程，提高用户体验。通过智能化的账号管理工具，用户可以轻松管理多个账号，实现一键登录、快捷切换，节省时间，提高效率。</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="block-style-two block-icon-animate animated-hover-icon d-flex mb-30" data-aos="fade-up" data-aos-delay="50">
                            <div class="icon bg-three">
                                <i class="flaticon-digital-marketing"></i>
                            </div>
                            <div class="text">
                                <p>利用先进的订单监控系统，实时跟踪订单状态，确保订单处理的及时性和准确性。通过对订单流程的实时监控，可以快速响应订单变化，提高处理效率，增强客户满意度。</p>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6 col-sm-12">
                        <div class="block-style-two block-icon-animate animated-hover-icon d-flex mb-30" data-aos="fade-up" data-aos-delay="60">
                            <div class="icon bg-four">
                                <i class="flaticon-content"></i>
                            </div>
                            <div class="text">
                                <p>一次轻松接入所有支付（QQ钱包，支付宝，微信），省时省心省力， 结算费率低，利润高！对接费率超低，比其它平台更便宜。全天监视订单 和资金安全，正规支付接口！</p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--====== End Blog Section ======-->
        <!--====== Start Newsletter Section ======-->
        <section class="cta-area cta-style-one blue-dark">
            <div class="shape shape-one scene"><span data-depth="5"></span></div>
            <div class="shape shape-two scene"><span data-depth=".5"></span></div>
            <div class="shape shape-three scene"><span data-depth="3"></span></div>
            <div class="shape shape-four scene"><span data-depth="4"></span></div>
            <div class="container">
                <div class="row">
                    <div class="col-lg-6">
                        <div class="text-wrapper pt-90 pb-100" data-aos="fade-up" data-aos-delay="30">
                            <div class="section-title section-title-white">
                                <h2>极速响应、安全可靠、方便快捷是我们最大的特点，轻松实现手机付款、在线付款。
                                    </h2>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-6">
                        <div class="cta-img"><img src="assets/images/cta/cta-img-1.png" alt="CTA Image"></div>
                    </div>
                </div>
            </div>
        </section>
        <!--====== End Newsletter Section ======-->
        <!--====== Start Footer ======-->
        <footer class="footer-area footer-default">
            <div class="container">
                <div class="footer-widget pt-100 pb-55">
                    <div class="row">
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="widget about-widget mb-40" data-aos="fade-up" data-aos-delay="30">
                                <div class="site-branding">
                                    <a href="index.html"><img src="https://www.wmhua.cn/i/2025/01/12/678342fdcf356.png" alt="Site Logo"></a>
                                </div>
                                <p>极速响应、安全可靠、方便快捷是我们最大的特点，轻松实现手机付款、在线付款。</p>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="widget footer-nav-widget mb-40" data-aos="fade-up" data-aos-delay="40">
                                <h4 class="widget-title">关于我们</h4>
                                <ul class="footer-nav">
                                    <li><a href="#">联系我们</a></li>
                                    <li><a href="#">支付测试</a></li>
                                    <li><a href="#">商户登录</a></li>
                                    <li><a href="#">商户注册</a></li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="widget footer-nav-widget" data-aos="fade-up" data-aos-delay="50">
                                <div class="widget footer-nav-widget mb-40">
                                    <h4 class="widget-title">用户协议</h4>
                                    <ul class="footer-nav">
                                        <li><a href="#">禁售商品</a></li>
                                        <li><a href="#">隐私协议</a></li>
                                        <li><a href="#">注册协议</a></li>
                                        <li><a href="#">服务条款</a></li>
                                    </ul>
                                </div>
                            </div>
                        </div>
                        <div class="col-lg-3 col-md-6 col-sm-12">
                            <div class="widget newsletter-widget mb-40" data-aos="fade-up" data-aos-delay="60">
                                <h4 class="widget-title">信息反馈</h4>
                                <div class="newsletter-content">
                                    <p>Subscribe to get the latest news form us</p>
                                    <form>
                                        <div class="form_group">
                                            <input type="email" class="form_control" placeholder="Email" name="email" required>
                                            <button class="newsletter-btn"><i class="fas fa-paper-plane"></i></button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <div class="footer-copyright">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="text text-center">
                                <p>&copy; Copyright 2022 易付通 备案号：<a href="https://beian.miit.gov.cn/">豫ICP备2024096013号-1</a></p>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </footer>
        <!--====== End Footer ======-->
        <!--====== back-to-top ======-->
        <a href="#" class="back-to-top" ><i class="far fa-angle-up"></i></a>
        <!--====== Jquery js ======-->
        <script src="assets/vendor/jquery-3.6.0.min.js"></script>
        <!--====== Bootstrap js ======-->
        <script src="assets/vendor/popper/popper.min.js"></script>
        <!--====== Bootstrap js ======-->
        <script src="assets/vendor/bootstrap/js/bootstrap.min.js"></script>
        <!--====== Slick js ======-->
        <script src="assets/vendor/slick/slick.min.js"></script>
        <!--====== Magnific js ======-->
        <script src="assets/vendor/magnific-popup/dist/jquery.magnific-popup.min.js"></script>
        <!--====== Counterup js ======-->
        <script src="assets/vendor/jquery.counterup.min.js"></script>
        <!--====== Waypoints js ======-->
        <script src="assets/vendor/jquery.waypoints.js"></script>
        <!--====== Parallax js ======-->
        <script src="assets/vendor/parallax.min.js"></script>
        <!--====== AOS js ======-->
        <script src="assets/vendor/aos/aos.js"></script>
        <!--====== Main js ======-->
        <script src="assets/js/theme.js"></script>
    </body>
</html>